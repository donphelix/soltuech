<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'name',
        'description',
        'quantity'       
    ];

    public function product(){
        return $this->belongsTo('App\Product');
    }

    public function supplier_products(){
        return $this->belongsTo('App\SupplierProducts');
    }

    public function orders_details(){
        return $this->belongsTo('App\OrderDetails');
    }

}
