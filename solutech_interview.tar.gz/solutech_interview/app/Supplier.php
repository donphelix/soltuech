<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    protected $fillable = [
        'name'       
    ];

    public function supplier(){
        return $this->belongsTo('App\Supplier');
    }

    public function supply_details(){
        return $this->belongsTo('App\SupplyDetails');
    }
}
