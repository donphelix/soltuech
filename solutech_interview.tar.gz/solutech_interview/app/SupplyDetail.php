<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupplyDetail extends Model
{
    public function supplier(){
        return $this->hasMany('App\Supplier');
    }
}
